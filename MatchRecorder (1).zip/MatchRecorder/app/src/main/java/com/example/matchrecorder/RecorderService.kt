package com.example.matchrecorder

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*

private data class Plan(val w: Int, val h: Int, val dpi: Int, val bitrate: Int, val fps: Int)

class RecorderService : Service() {
    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_CLIP = "clip"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_SECONDS = "sec"
        const val UPDATE = "com.example.matchrecorder.UPDATE"
        const val RATE = 44100
        @Volatile var running = false
        @Volatile var startedAt = 0L
        @Volatile var marks = 0

        /** Widest H.264 frame the phone's hardware encoder accepts. */
        fun maxEncoderWidth(): Int {
            var w = 0
            for (ci in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
                if (!ci.isEncoder || ci.isSoftwareOnly) continue
                if (MediaFormat.MIMETYPE_VIDEO_AVC !in ci.supportedTypes) continue
                val vc = ci.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC).videoCapabilities
                w = maxOf(w, vc.supportedWidths.upper)
            }
            return w
        }
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var venc: MediaCodec? = null
    private var aenc: MediaCodec? = null
    private var vdisplay: VirtualDisplay? = null
    private lateinit var muxer: MediaMuxer
    private var pfd: ParcelFileDescriptor? = null
    private var outUri: Uri? = null
    private val mux = Any()
    @Volatile private var vTrack = -1
    @Volatile private var aTrack = -1
    @Volatile private var muxStarted = false
    @Volatile private var active = false
    private var startUs = 0L
    private val marksList = Collections.synchronizedList(mutableListOf<Pair<Long, Int>>())
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_CLIP -> if (active) clip(intent.getIntExtra(EXTRA_SECONDS, 30)) else stopSelf()
            ACTION_STOP -> if (active) active = false else stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun pi(action: String, sec: Int = 0, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, RecorderService::class.java).setAction(action).putExtra(EXTRA_SECONDS, sec),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Recording", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Recording screen + internal audio")
            .setContentText("Tap a clip button right after a big moment")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_save, "Clip 30s", pi(ACTION_CLIP, 30, 1))
            .addAction(android.R.drawable.ic_menu_save, "Clip 60s", pi(ACTION_CLIP, 60, 2))
            .addAction(android.R.drawable.ic_media_pause, "Stop", pi(ACTION_STOP, 0, 3))
            .build()
    }

    /** Picks the best size/fps the encoder supports, stepping down from what the user asked for. */
    @Suppress("DEPRECATION")
    private fun plan(quality: Int, fps: Int): Plan {
        val dm = DisplayMetrics()
        getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(dm)
        val nw = maxOf(dm.widthPixels, dm.heightPixels)   // always record landscape
        val nh = minOf(dm.widthPixels, dm.heightPixels)
        val codecs = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        for (q in quality downTo 0) for (f in listOf(fps, 30).distinct()) {
            val sh = when (q) { 0 -> 720; 1 -> minOf(1080, nh); else -> 2160 }
            var s = sh.toFloat() / nh
            if (nw * s > 4096) s = 4096f / nw
            val w = (nw * s).toInt() / 16 * 16
            val h = (nh * s).toInt() / 16 * 16
            val br = when (q) { 0 -> 8_000_000; 1 -> 16_000_000; else -> 40_000_000 } * (if (f > 30) 3 else 2) / 2
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, br)
                setInteger(MediaFormat.KEY_FRAME_RATE, f)
            }
            if (codecs.findEncoderForFormat(fmt) != null) return Plan(w, h, dm.densityDpi, br, f)
        }
        return Plan(1280, 720, dm.densityDpi, 8_000_000, 30)
    }

    @Suppress("DEPRECATION")
    private fun start(intent: Intent) {
        if (active) return
        try {
            startForeground(1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            vTrack = -1; aTrack = -1; muxStarted = false; marksList.clear(); marks = 0
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)!!
            val proj = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data)
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { active = false }
            }, main)
            projection = proj

            val prefs = getSharedPreferences("prefs", 0)
            val p = plan(prefs.getInt("quality", 1), prefs.getInt("fps", 30))

            // ---- video encoder (fed by the screen through a surface)
            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, p.w, p.h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, p.bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, p.fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)   // keyframe every second = clean clip cuts
                setInteger("max-fps-to-encoder", p.fps)
            }
            val name = MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(vf)
                ?: MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(
                    MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, p.w, p.h))
            val ve = MediaCodec.createByCodecName(name!!)
            ve.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = ve.createInputSurface()
            ve.start()
            venc = ve
            vdisplay = proj.createVirtualDisplay(
                "rec", p.w, p.h, p.dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)

            // ---- audio: capture other apps' sound, encode to AAC
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val pcmFmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            record = AudioRecord.Builder()
                .setAudioFormat(pcmFmt)
                .setAudioPlaybackCaptureConfig(cfg)
                .setBufferSizeInBytes(maxOf(minBuf, 65536) * 2)
                .build()
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val ae = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            ae.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            ae.start()
            aenc = ae

            // ---- output file written straight into Movies/MatchRecorder
            val uri = newVideoUri("match_${stamp()}.mp4")
            outUri = uri
            pfd = contentResolver.openFileDescriptor(uri, "rw")!!
            muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            startUs = System.nanoTime() / 1000
            record!!.startRecording()
            active = true
            running = true
            startedAt = SystemClock.elapsedRealtime()
            sendBroadcast(Intent(UPDATE).setPackage(packageName))
            toast("Recording ${p.w}x${p.h} at ${p.fps} fps")
            Thread { session() }.start()
        } catch (e: Exception) {
            toast("Could not start: ${e.message}")
            releaseAll()
            outUri?.let { contentResolver.delete(it, null, null) }
            cleanup()
        }
    }

    private fun session() {
        val vt = Thread { videoLoop() }
        val at = Thread { audioLoop() }
        vt.start(); at.start()
        while (active) Thread.sleep(100)
        try { venc?.signalEndOfInputStream() } catch (_: Exception) {}
        at.join(); vt.join()
        finish()
    }

    private fun tryStartMux() {
        if (vTrack >= 0 && aTrack >= 0 && !muxStarted) { muxer.start(); muxStarted = true }
    }

    private fun videoLoop() {
        val enc = venc!!
        val info = MediaCodec.BufferInfo()
        var last = -1L
        while (true) {
            val i = enc.dequeueOutputBuffer(info, 10_000)
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                synchronized(mux) { vTrack = muxer.addTrack(enc.outputFormat); tryStartMux() }
            } else if (i >= 0) {
                val buf = enc.getOutputBuffer(i)!!
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (info.size > 0 && muxStarted) {
                    var t = info.presentationTimeUs - startUs
                    if (t < 0) t = 0
                    if (t <= last) t = last + 1
                    last = t
                    info.presentationTimeUs = t
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    synchronized(mux) { muxer.writeSampleData(vTrack, buf, info) }
                }
                enc.releaseOutputBuffer(i, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
            }
        }
    }

    private fun audioLoop() {
        val rec = record!!
        val enc = aenc!!
        val info = MediaCodec.BufferInfo()
        val pcm = ByteArray(4096)
        var frames = 0L
        var base = -1L
        var last = -1L

        fun drain(wait: Long): Boolean {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, wait)
                if (i == MediaCodec.INFO_TRY_AGAIN_LATER) return false
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    synchronized(mux) { aTrack = muxer.addTrack(enc.outputFormat); tryStartMux() }
                } else if (i >= 0) {
                    val buf = enc.getOutputBuffer(i)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && muxStarted) {
                        var t = info.presentationTimeUs
                        if (t <= last) t = last + 1
                        last = t
                        info.presentationTimeUs = t
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        synchronized(mux) { muxer.writeSampleData(aTrack, buf, info) }
                    }
                    enc.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                }
            }
        }

        while (active) {
            val n = rec.read(pcm, 0, pcm.size)
            if (n < 0) break
            if (n == 0) continue
            if (base < 0) base = maxOf(0L, System.nanoTime() / 1000 - startUs - (n / 4) * 1_000_000L / RATE)
            val idx = enc.dequeueInputBuffer(20_000)
            if (idx >= 0) {
                val b = enc.getInputBuffer(idx)!!
                b.clear(); b.put(pcm, 0, n)
                enc.queueInputBuffer(idx, 0, n, base + frames * 1_000_000L / RATE, 0)
                frames += n / 4
            }
            drain(0)
        }
        var idx = -1
        for (k in 0 until 50) { idx = enc.dequeueInputBuffer(20_000); if (idx >= 0) break }
        if (idx >= 0) {
            enc.queueInputBuffer(idx, 0, 0, maxOf(0L, base) + frames * 1_000_000L / RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            for (k in 0 until 100) if (drain(20_000)) break
        }
    }

    private fun clip(sec: Int) {
        val t = System.nanoTime() / 1000 - startUs
        marksList.add(Pair(t, sec))
        marks = marksList.size
        sendBroadcast(Intent(UPDATE).setPackage(packageName))
        toast("Clip marked (last ${sec}s). It is cut when you stop.")
    }

    private fun finish() {
        running = false
        sendBroadcast(Intent(UPDATE).setPackage(packageName))
        var ok = false
        try { if (muxStarted) { muxer.stop(); ok = true } } catch (_: Exception) {}
        try { muxer.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        releaseAll()
        val uri = outUri
        if (uri != null) {
            if (ok) {
                publish(uri)
                val m = marksList.toList()
                if (m.isNotEmpty()) { toast("Cutting ${m.size} clip(s)..."); cutClips(uri, m) }
                toast("Saved to Movies/MatchRecorder")
            } else {
                contentResolver.delete(uri, null, null)
                toast("Nothing was recorded. That app may block screen capture.")
            }
        }
        cleanup()
    }

    private fun cutClips(src: Uri, m: List<Pair<Long, Int>>) {
        val s = stamp()
        m.forEachIndexed { n, (t, sec) ->
            val dst = newVideoUri("clip_${n + 1}_${sec}s_$s.mp4")
            try {
                cut(src, maxOf(0L, t - sec * 1_000_000L), t, dst)
                publish(dst)
            } catch (e: Exception) {
                contentResolver.delete(dst, null, null)
            }
        }
    }

    /** Copies samples between two times without re-encoding, so clips keep full quality. */
    private fun cut(src: Uri, startUs: Long, endUs: Long, dst: Uri) {
        val inPfd = contentResolver.openFileDescriptor(src, "r")!!
        val outPfd = contentResolver.openFileDescriptor(dst, "rw")!!
        val ex = MediaExtractor()
        ex.setDataSource(inPfd.fileDescriptor)
        val mx = MediaMuxer(outPfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val map = IntArray(ex.trackCount)
        for (i in 0 until ex.trackCount) { ex.selectTrack(i); map[i] = mx.addTrack(ex.getTrackFormat(i)) }
        ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        mx.start()
        val buf = ByteBuffer.allocate(8 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var base = -1L
        while (true) {
            val size = ex.readSampleData(buf, 0)
            if (size < 0) break
            val t = ex.sampleTime
            if (t > endUs) break
            if (base < 0) base = t
            info.set(0, size, maxOf(0L, t - base), ex.sampleFlags)
            mx.writeSampleData(map[ex.sampleTrackIndex], buf, info)
            ex.advance()
        }
        mx.stop(); mx.release(); ex.release()
        inPfd.close(); outPfd.close()
    }

    private fun newVideoUri(name: String): Uri {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MatchRecorder")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
    }

    private fun publish(uri: Uri) {
        contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        sendBroadcast(Intent(UPDATE).setPackage(packageName))
    }

    private fun releaseAll() {
        try { venc?.stop() } catch (_: Exception) {}
        try { venc?.release() } catch (_: Exception) {}
        venc = null
        try { aenc?.stop() } catch (_: Exception) {}
        try { aenc?.release() } catch (_: Exception) {}
        aenc = null
        try { vdisplay?.release() } catch (_: Exception) {}
        vdisplay = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun toast(m: String) = main.post { Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show() }

    private fun cleanup() {
        active = false
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        sendBroadcast(Intent(UPDATE).setPackage(packageName))
        stopSelf()
    }
}
