package com.example.matchrecorder

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0B0F14")
    private val CARD = Color.parseColor("#151B23")
    private val RED = Color.parseColor("#E5484D")
    private val ACCENT = Color.parseColor("#3B82F6")
    private val MUTED = Color.parseColor("#8B96A5")

    private data class Rec(val uri: Uri, val name: String, val size: Long, val durMs: Long)

    private val recs = mutableListOf<Rec>()
    private val thumbs = HashMap<Uri, Bitmap>()
    private lateinit var prefs: SharedPreferences
    private lateinit var recBtn: TextView
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { updateStatus(); ui.postDelayed(this, 1000) }
    }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = refresh()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, sp: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun segmented(labels: List<String>, key: String, values: List<Int>, def: Int): LinearLayout {
        val row = LinearLayout(this).apply { background = bg(BG, 12); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        val views = mutableListOf<TextView>()
        fun paint() {
            val cur = prefs.getInt(key, def)
            views.forEachIndexed { i, v ->
                v.background = if (values[i] == cur) bg(ACCENT, 10) else null
                v.setTextColor(if (values[i] == cur) Color.WHITE else MUTED)
            }
        }
        labels.forEachIndexed { i, l ->
            val v = tv(l, 14f, MUTED, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { prefs.edit().putInt(key, values[i]).apply(); paint() }
            }
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        }
        paint()
        return row
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = recs.size
        override fun getItem(p: Int) = recs[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val r = recs[p]
            val row = LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = bg(CARD, 14)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            val img = ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#222B36"))
            }
            row.addView(img, LinearLayout.LayoutParams(dp(112), dp(63)))
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            col.addView(tv(r.name.removeSuffix(".mp4"), 15f, Color.WHITE, true))
            col.addView(tv("${fmt(r.durMs)}  ·  ${r.size / 1_000_000} MB", 13f, MUTED))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            thumb(r.uri, img)
            return row
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = getSharedPreferences("prefs", 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(20), dp(44), dp(20), dp(12))
        }
        root.addView(tv("Match Recorder", 26f, Color.WHITE, true))
        root.addView(tv("Screen + internal audio  ·  no microphone", 13f, MUTED))

        recBtn = tv("", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = bg(RED, 22)
            setOnClickListener { toggle() }
        }
        root.addView(recBtn, LinearLayout.LayoutParams(-1, dp(80)).apply { topMargin = dp(18) })
        status = tv("", 13f, MUTED).apply { gravity = Gravity.CENTER }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val clips = LinearLayout(this)
        for (sec in listOf(30, 60)) {
            val b = tv("✂  Clip last ${sec}s", 15f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = bg(CARD, 14)
                setOnClickListener { clip(sec) }
            }
            clips.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(4), dp(10), dp(4), 0) })
        }
        root.addView(clips)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(CARD, 16)
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        card.addView(tv("Quality", 12f, MUTED))
        card.addView(segmented(listOf("720p", "1080p", "4K"), "quality", listOf(0, 1, 2), 1))
        card.addView(tv("Frame rate", 12f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        card.addView(segmented(listOf("30 fps", "60 fps"), "fps", listOf(30, 60), 30))
        val w = RecorderService.maxEncoderWidth()
        val note = "Landscape capture. 4K is upscaled from your screen and drops to the best size the phone can encode" +
            if (w > 0) " (hardware limit: ${w}px wide)." else "."
        card.addView(tv(note, 11f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        root.addView(tv("Recordings", 16f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, dp(8)) })
        val list = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(10)
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(recs[pos].uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
            setOnItemLongClickListener { _, _, pos, _ -> options(pos); true }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(RecorderService.UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        refresh()
        ui.post(tick)
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(receiver)
        ui.removeCallbacks(tick)
    }

    private fun updateStatus() {
        if (RecorderService.running) {
            val s = (SystemClock.elapsedRealtime() - RecorderService.startedAt) / 1000
            recBtn.text = "■   STOP"
            status.setTextColor(RED)
            status.text = "● REC  ${fmt(s * 1000)}  ·  ${RecorderService.marks} clip(s) marked"
        } else {
            recBtn.text = "●   START RECORDING"
            status.setTextColor(MUTED)
            status.text = "Ready. Clips are cut automatically when you stop."
        }
    }

    private fun toggle() {
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(need.toTypedArray(), 1)
        } else askCapture()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) askCapture()
        else Toast.makeText(this, "Microphone permission is required for audio capture", Toast.LENGTH_LONG).show()
    }

    @Suppress("DEPRECATION")
    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 42 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, RecorderService::class.java)
                    .setAction(RecorderService.ACTION_START)
                    .putExtra(RecorderService.EXTRA_CODE, res)
                    .putExtra(RecorderService.EXTRA_DATA, data)
            )
        }
    }

    private fun clip(sec: Int) {
        if (!RecorderService.running) { Toast.makeText(this, "Start recording first", Toast.LENGTH_SHORT).show(); return }
        startService(Intent(this, RecorderService::class.java)
            .setAction(RecorderService.ACTION_CLIP).putExtra(RecorderService.EXTRA_SECONDS, sec))
    }

    private fun refresh() {
        recs.clear()
        val u = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(
            u,
            arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DURATION),
            "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("Movies/MatchRecorder%"),
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext())
                recs.add(Rec(ContentUris.withAppendedId(u, c.getLong(0)), c.getString(1), c.getLong(2), c.getLong(3)))
        }
        adapter.notifyDataSetChanged()
        updateStatus()
    }

    private fun thumb(u: Uri, img: ImageView) {
        thumbs[u]?.let { img.setImageBitmap(it); return }
        Thread {
            try {
                val b = contentResolver.loadThumbnail(u, Size(336, 189), null)
                runOnUiThread { thumbs[u] = b; img.setImageBitmap(b) }
            } catch (_: Exception) {}
        }.start()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }

    private fun options(pos: Int) {
        val r = recs[pos]
        AlertDialog.Builder(this).setTitle(r.name)
            .setItems(arrayOf("Share", "Delete")) { _, which ->
                if (which == 0) {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, r.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Share"))
                } else {
                    contentResolver.delete(r.uri, null, null); refresh()
                }
            }.show()
    }
}
