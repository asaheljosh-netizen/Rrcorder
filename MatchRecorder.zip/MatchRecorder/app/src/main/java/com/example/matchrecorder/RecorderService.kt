package com.example.matchrecorder

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.MediaStore
import android.widget.Toast
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : Service() {
    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_CLIP = "clip"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_SECONDS = "sec"
        const val UPDATE = "com.example.matchrecorder.UPDATE"
        const val RATE = 44100
        const val BYTES_PER_SEC = RATE * 2 * 2          // stereo, 16-bit
        const val MAX_BUFFER_SEC = 120                  // longest clip you can grab
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    @Volatile private var active = false
    private val ring = ByteArray(BYTES_PER_SEC * MAX_BUFFER_SEC)
    private var ringPos = 0
    private var ringFilled = 0
    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_CLIP -> if (active) clip(intent.getIntExtra(EXTRA_SECONDS, 30)) else stopSelf()
            ACTION_STOP -> if (active) active = false else stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun pi(action: String, sec: Int = 0, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, RecorderService::class.java).setAction(action).putExtra(EXTRA_SECONDS, sec),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Recording", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Recording internal audio")
            .setContentText("Tap Clip to save the last moments")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_save, "Clip 30s", pi(ACTION_CLIP, 30, 1))
            .addAction(android.R.drawable.ic_menu_save, "Clip 60s", pi(ACTION_CLIP, 60, 2))
            .addAction(android.R.drawable.ic_media_pause, "Stop", pi(ACTION_STOP, 0, 3))
            .build()
    }

    @Suppress("DEPRECATION")
    private fun start(intent: Intent) {
        if (active) return
        try {
            startForeground(1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)!!
            val proj = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data)
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { active = false }
            }, main)
            projection = proj

            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            record = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setAudioPlaybackCaptureConfig(cfg)
                .setBufferSizeInBytes(maxOf(minBuf, 65536) * 2)
                .build()
            record!!.startRecording()
            active = true
            running = true
            sendBroadcast(Intent(UPDATE).setPackage(packageName))
            Thread { recordLoop() }.start()
        } catch (e: Exception) {
            toast("Could not start: ${e.message}")
            cleanup()
        }
    }

    private fun recordLoop() {
        val tmp = File(getExternalFilesDir(null), "tmp_full.wav")
        var total = 0L
        try {
            BufferedOutputStream(FileOutputStream(tmp)).use { out ->
                out.write(ByteArray(44))
                val buf = ByteArray(8192)
                while (active) {
                    val n = record!!.read(buf, 0, buf.size)
                    if (n > 0) {
                        out.write(buf, 0, n)
                        total += n
                        synchronized(lock) { addRing(buf, n) }
                    }
                }
            }
            RandomAccessFile(tmp, "rw").use { it.write(header(total)) }
            if (total > 0) {
                export(tmp, "match_${stamp()}.wav")
                toast("Recording saved")
            }
        } catch (e: Exception) {
            toast("Recording error: ${e.message}")
        } finally {
            tmp.delete()
            cleanup()
        }
    }

    private fun addRing(b: ByteArray, n: Int) {
        val first = minOf(n, ring.size - ringPos)
        System.arraycopy(b, 0, ring, ringPos, first)
        if (first < n) System.arraycopy(b, first, ring, 0, n - first)
        ringPos = (ringPos + n) % ring.size
        ringFilled = minOf(ring.size, ringFilled + n)
    }

    private fun clip(sec: Int) {
        val out: ByteArray
        synchronized(lock) {
            var n = minOf(sec * BYTES_PER_SEC, ringFilled)
            n -= n % 4
            out = ByteArray(n)
            val start = (ringPos - n + ring.size) % ring.size
            val first = minOf(n, ring.size - start)
            System.arraycopy(ring, start, out, 0, first)
            System.arraycopy(ring, 0, out, first, n - first)
        }
        Thread {
            val tmp = File(getExternalFilesDir(null), "tmp_clip.wav")
            tmp.outputStream().use { it.write(header(out.size.toLong())); it.write(out) }
            export(tmp, "clip_${sec}s_${stamp()}.wav")
            tmp.delete()
            toast("Clip saved (${out.size / BYTES_PER_SEC}s)")
        }.start()
    }

    private fun export(src: File, name: String) {
        val v = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/MatchRecorder")
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { o -> src.inputStream().use { i -> i.copyTo(o) } }
        sendBroadcast(Intent(UPDATE).setPackage(packageName))
    }

    private fun header(dataLen: Long): ByteArray =
        ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray()); putInt((36 + dataLen).toInt())
            put("WAVE".toByteArray()); put("fmt ".toByteArray()); putInt(16)
            putShort(1); putShort(2); putInt(RATE); putInt(BYTES_PER_SEC)
            putShort(4); putShort(16)
            put("data".toByteArray()); putInt(dataLen.toInt())
        }.array()

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun toast(m: String) = main.post { Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show() }

    private fun cleanup() {
        active = false
        running = false
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        sendBroadcast(Intent(UPDATE).setPackage(packageName))
        stopSelf()
    }
}
