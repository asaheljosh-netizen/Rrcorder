package com.example.matchrecorder

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var recBtn: Button
    private lateinit var list: ListView
    private val items = mutableListOf<Triple<Long, String, Long>>() // id, name, bytes
    private var player: MediaPlayer? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = refresh()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        recBtn = Button(this).apply {
            textSize = 22f; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#D32F2F"))
            setOnClickListener { toggle() }
        }
        root.addView(recBtn, LinearLayout.LayoutParams(-1, 280))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (sec in listOf(30, 60)) {
            row.addView(Button(this).apply {
                text = "Clip last ${sec}s"
                setOnClickListener { clip(sec) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(row)
        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        list.setOnItemClickListener { _, _, pos, _ -> play(pos) }
        list.setOnItemLongClickListener { _, _, pos, _ -> options(pos); true }
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(RecorderService.UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        refresh()
    }

    override fun onStop() { super.onStop(); unregisterReceiver(receiver) }

    private fun toggle() {
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(need.toTypedArray(), 1)
        } else askCapture()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) askCapture()
        else Toast.makeText(this, "Microphone permission is required for audio capture", Toast.LENGTH_LONG).show()
    }

    @Suppress("DEPRECATION")
    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 42 && res == RESULT_OK && data != null) {
            player?.release(); player = null
            startForegroundService(
                Intent(this, RecorderService::class.java)
                    .setAction(RecorderService.ACTION_START)
                    .putExtra(RecorderService.EXTRA_CODE, res)
                    .putExtra(RecorderService.EXTRA_DATA, data)
            )
        }
    }

    private fun clip(sec: Int) {
        if (!RecorderService.running) { Toast.makeText(this, "Start recording first", Toast.LENGTH_SHORT).show(); return }
        startService(Intent(this, RecorderService::class.java)
            .setAction(RecorderService.ACTION_CLIP).putExtra(RecorderService.EXTRA_SECONDS, sec))
    }

    private fun refresh() {
        recBtn.text = if (RecorderService.running) "■  STOP RECORDING" else "●  START RECORDING"
        items.clear()
        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE),
            "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?", arrayOf("Music/MatchRecorder%"),
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) items.add(Triple(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            items.map { "${it.second}\n${it.third / 1_000_000} MB" })
    }

    private fun uri(pos: Int): Uri =
        Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, items[pos].first.toString())

    private fun play(pos: Int) {
        if (RecorderService.running) { Toast.makeText(this, "Stop recording before playing back", Toast.LENGTH_SHORT).show(); return }
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(this@MainActivity, uri(pos)); prepare(); start()
            setOnCompletionListener { it.release(); player = null }
        }
    }

    private fun options(pos: Int) {
        AlertDialog.Builder(this).setTitle(items[pos].second)
            .setItems(arrayOf("Share", "Delete")) { _, which ->
                if (which == 0) {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "audio/wav"; putExtra(Intent.EXTRA_STREAM, uri(pos))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Share"))
                } else {
                    player?.release(); player = null
                    contentResolver.delete(uri(pos), null, null); refresh()
                }
            }.show()
    }
}
